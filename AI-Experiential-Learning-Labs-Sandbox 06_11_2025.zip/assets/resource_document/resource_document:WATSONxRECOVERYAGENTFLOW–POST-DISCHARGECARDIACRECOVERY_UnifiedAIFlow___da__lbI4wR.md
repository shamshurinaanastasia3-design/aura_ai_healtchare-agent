# **WATSONx RECOVERY AGENT FLOW – POST-DISCHARGE CARDIAC RECOVERY (Unified AI Flow)**

**This document provides the unified AI flow for the Watsonx Recovery Agent tailored to post-discharge cardiac recovery. It combines the recovery plan specifics with the hospital system user-experience design to produce an actionable orchestration plan for developers and implementers.**

## **Overview**

**Purpose: Provide an integrated, runnable flow for watsonx.ai and Watson Orchestrate. The flow ensures daily adherence, period-based recovery orchestration, safe escalation, and caregiver integration. Designed for both Priority and Standard user modes.**

## **1. USER IDENTIFICATION & PROFILE INITIALIZATION**

**Event: Patient logs into the recovery app after hospital discharge.**

**System Actions:**

**1. Retrieve User ID / Patient ID from the hospital EHR/CRM.**

**2. Load patient profile: procedure, doctor, recovery plan, contact and caregiver info.**

**3. Check Priority User flag (YES/NO).**

**Dialogue Flow:**

**Priority User: "Hello \[Patient Name]. Welcome home. I’ll guide you step-by-step through your recovery plan. Let's confirm your caregiver information."**

**Standard User: "Hello \[Patient Name]. Welcome home! Let’s get you started with your recovery plan. Please confirm if you have a caregiver assisting you."**

## **2. CAREGIVER CONFIRMATION & MODE SELECTION**

**Purpose: Determine assistance level and set interaction mode.**

**Logic:**

**- If Priority User AND Caregiver Present → Set Mode = Standard (reduce extra guidance).**

**- If Priority User AND Caregiver NOT present → Set Mode = Priority (enhanced guidance, audio support).**

**- If Standard User → Set Mode = Standard.**

## **3. RECOVERY PLAN ACTIVATION & DATA SOURCES**

**System retrieves recovery plan linked to User ID from the database or uploaded Excel/PDF. The plan includes:**

**- Medication schedule (dose, time, before/after meals).**

**- Vital sign checks (BP schedule, heart rate).**

**- Follow-up appointment schedule (pre-call forms).**

**- Diet & water prescriptions and additional notes.**

**Action: AI Agent confirms plan and requests permission to send push notifications. And user gives a recovery plan as attached file and also AI Agent offer to save the file and also explains that the patient can find more information about Recovery plan on the dashboard.**

## **4. PERIOD-BASED LOGIC & NOTIFICATION SCHEDULER**

**Recovery periods are orchestrated by Watson Orchestrate and mapped to events:**

**- Period 1 (5 days): Stabilization — Daily BP checks at 9AM/9PM; Discharge instructions; Follow-up call at end of period.**

**- Period 2 (10 days): Gradual resumption — Med adherence checks; Follow-up call and blood tests as scheduled.**

**- Period 3 (15 days): Assessment — Continued monitoring; nutritional advice; final follow-up call.**

**- Long-Term: Monthly maintenance — Monthly reminders, activity encouragement, ongoing monitoring.**

## **5. DAILY ADHERENCE SEQUENCE (Automated by watsonx.ai)**

**Triggers: 09:00 AM & 09:00 PM (configurable per patient profile).**

**Steps:**

**1) Vital Check: Prompt user to input BP in format 'systolic/diastolic' and optional heart rate. Validate format. If no response in 15 minutes, initiate No-Response Protocol.**

**2) Medication Adherence: Present medication list dynamically from the recovery plan (placeholders). Ask: 'Have you taken your \[Medication Name]? (Yes/No/Partial)'. Log timestamps and adherence percentage.**

**3) Symptom Check (if triggered): Ask for chest pain rating 1-10 and other symptoms.**

**4) Diet & Water Reminder: Send daily guidance and hydration reminder.**

**5) Unfinished Task Check: Detect postponed mandatory tasks and prompt completion before session closure.**

## **6. SYMPTOM CHECK & RISK ESCALATION PROTOCOL**

**Symptom assessment logic:**

**- If pain 1-5: Log and provide reassurance. Continue routine.**

**- If pain 6-8: Log, flag as medium risk, notify care team, schedule clinician review.**

**- If pain >= 9: Initiate Stage 1 secondary BP check. If BP confirms instability or non-response, trigger CRITICAL ALERT: notify hospital, caregiver, and initiate emergency protocol.**

**Notes: Always request a secondary objective measurement before final escalation when feasible. Use SMS/call cascade for critical alerts.**

## **7. PRE-DOCTOR CALL FORM & EHR INTEGRATION**

**Trigger: 3 days prior to scheduled follow-up call.**

**Flow:**

**- AI Agent prompts user to complete pre-call form: recent BP averages, medication adherence %, symptom summary, and list of questions for doctor.**

**- On completion, generate PDF and attach to patient EHR via FHIR API. Notify clinician of submitted form.**

## **8. CHAT FLOW & RECOVERY PLAN ACCESS**

**In-chat messaging example: 'There’s a Recovery Plan for you, Patient! You need to follow the schedule, prescriptions, and plan two sessions with your doctor — after 5 days and after 10 days. Please read all details carefully.'**

**Features: View Plan PDF, Export Plan as PDF from chat, Set custom reminders, Contact doctor. All chat interactions are linked to User ID and persisted in watsonx conversation logs.**

## **9. WEEKLY FEEDBACK & CLOSURE**

**Weekly Satisfaction Prompt: 'On a scale of 1–10, how satisfied are you with your recovery support this week?'**

**End-of-Day: 'Thank you for today’s check-in. I’ll remind you again tomorrow at \[Time].'**

**30-Day Completion: Generate end-of-cycle summary and send to care team.**

## **10. LONG-TERM MANAGEMENT & ANALYTICS**

**Post-30 days: Schedule monthly follow-ups, track adherence metrics, and provide quarterly summary reports to clinicians. Produce analytics dashboards for patient adherence, risk events, and satisfaction trends.**

## **11. SYSTEM ARCHITECTURE & INTEGRATION POINTS**

**Components:**

**- Profile Loader: EHR/CRM integration to fetch User ID and patient metadata.**

**- Recovery Plan Manager: Stores and serves recovery plans (Excel/PDF).**

**- Notification Engine: Watson Orchestrate handles timed push notifications and reminder scheduling.**

**- Conversational Core: watsonx.ai manages dialogues, validation, and escalation logic.**

**- Care Team Interface: FHIR-compliant API to send pre-call forms, alerts, and reports to clinician systems.**

## **12. SECURITY, PRIVACY, AND ACCESSIBILITY**

**Ensure HIPAA-compliant data handling, encrypted transport, and role-based access to patient data. Support accessibility: screen reader-compatible messages, large tap targets, and clear language for Priority Users.**

## **13. EXAMPLE CONVERSATION SCRIPTS**

**Priority User Onboarding Script:**

**"Hello \[Patient Name]. Welcome home. I’ll guide you step-by-step through your recovery plan. Is your caregiver present right now to assist?"**

**Standard User Onboarding Script:**

**"Hello \[Patient Name]. Welcome back! Would you like to review your recovery plan and notification schedule now?"\
\
\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_**

**🧠 WATSONx RECOVERY AGENT FLOW – POST-DISCHARGE CARDIAC RECOVERY (Final Blueprint)**

**This represents how Watsonx.ai and Watson Orchestrate would interact with the patient through conversational prompts, logic branches, and automated orchestration events.\&#xA;**&#x20;**It’s formatted for developers and designers — ready for import into Watson Orchestrate or UI flow-mapping tools like Figma or Lucidchart.**



***



## **💬 CONVERSATIONAL FLOW (STEP-BY-STEP)**



***



### **1. ONBOARDING & PROFILE INITIALIZATION**

**Trigger: Patient opens the app after hospital discharge.**

**AI Agent:**

**“Welcome home, \[Patient Name]. I’m your Recovery Assistant.\&#xA;**&#x20;**I’ll help you follow your cardiac recovery plan safely and easily.”**

**System Actions:**

* **Retrieve User ID / Patient ID\&#xA;**
* **Load Recovery Plan (Procedure, Doctor, Schedule)\&#xA;**
* **Check Priority User flag (YES/NO)\&#xA;**



***



**If Priority User = YES:**

**AI Agent:**

**“Since you’re registered as a Priority User, I’ll provide extra support and step-by-step reminders.\&#xA;**&#x20;**Do you have a caregiver assisting you today?”**

**If caregiver = YES →** ***Switch to Standard Mode\&#xA;*** **If caregiver = NO →** ***Stay in Priority Mode (audio + simplified UI)***



***



**If Standard User = YES:**

**AI Agent:**

**“Would you like me to show you your recovery plan and upcoming reminders?”**

**(User responds “Yes” or “No”)**

**→ If Yes: Show Recovery Summary → Go to Period 1 Activation\&#xA;**&#x20;**→ If No: Offer “View Later” and set reminder in 2 hours.**



***



### **2. CARE PLAN ACTIVATION**

**AI Agent:**

**“Your personalized recovery plan is ready.\&#xA;**&#x20;**It includes your medication schedule, blood pressure checks, diet and water reminders, and doctor follow-ups.”**

**System:\&#xA;**&#x20;**Loads Recovery Plan from database → activates Period 1 triggers in Watson Orchestrate.**

**And user gives a recovery plan as attached file and also AI Agent offer to save the file and also explains that the patient can find more information about Recovery plan on the dashboard.**



**After that AI agents asks to red plan . This dialogue happens only once. After the user is ready the AI agent begins checking process**

**\&#xA;**



***



### **3. DAILY ADHERENCE CYCLE (AUTOMATED)**

**Triggers:**

* **09:00 AM → Morning Check\&#xA;**
* **09:00 PM → Evening Check\&#xA;**



***



#### **Morning Sequence Example (09:00 AM)**

**AI Agent:**

**“Good morning, \[Patient Name]. Let’s begin your daily recovery check.”**

**Step 1 – Vital Check**

**“Please share your blood pressure reading (e.g., 120/80).”\&#xA;**&#x20;**⏳** ***Waits for input; validates format.***

**If No response after 15 mins →**

**“I didn’t receive your reading. Would you like me to remind you again in 15 minutes?”\&#xA;**&#x20;**→ (If no reply after 30 mins → flag as missed reading → Log in Dashboard)**



***



**Step 2 – Medication Check**

**“Have you taken your morning medications?”**

**✅ If Yes:**

**“Perfect! I’ve logged your medication intake.”**

**⏳ If No:**

**“Would you like a reminder in 30 minutes or 1 hour?”**

**⚙️** ***System records medication timestamp, adherence rate (Watsonx.ai logs → Recovery Plan data).***



***



**Step 3 – Symptom Assessment**

**“On a scale of 1–10, how would you rate your chest pain or discomfort today?”**

**Input**

**System Response**

**Action**

**1–5**

**“Good to hear! Your vitals are stable. Keep following your plan.”**

**Log result**

**6–8**

**“I’ll log this and notify your care team to review your symptoms.”**

**Non-critical alert**

**9–10**

**“That sounds serious. Please take another blood pressure reading right now.”**

**Trigger Risk Escalation Subflow**

**If second BP reading confirms abnormal →\&#xA;**&#x20;**🚨 AI Agent: “I’m alerting your care team and contacting emergency support.”\&#xA;**&#x20;**(Trigger: Caregiver + Hospital Alert)**



***



**Step 4 – Lifestyle Reminder (After Breakfast)**

**“Don’t forget: Eat a light, low-sodium meal today, and drink at least 8 cups of water.”**



***



### **4. PERIOD-BASED LOGIC (SCHEDULED BY ORCHESTRATE)**

**Period**

**Duration**

**AI Triggers**

**Doctor Events**

**Period 1**

**Days 1–5**

**Daily AM/PM checks**

**Follow-up call (Day 6)**

**Period 2**

**Days 6–15**

**Continue AM/PM + blood test reminder**

**Doctor call (Day 12)**

**Period 3**

**Days 16–30**

**Weekly + daily reminders**

**Final call (Day 30)**

**Long-Term**

**Monthly**

**Monthly check-ins**

**Monthly teleconsults**

**AI Notification Example (Period 2):**

**“Hi \[Patient Name], your blood test is scheduled for tomorrow.\&#xA;**&#x20;**Please avoid coffee and heavy meals before the test.”**



***



### **5. PRE-DOCTOR CALL FORM FLOW**

**Trigger: 3 days before scheduled call.**

**AI Agent:**

**“You have a follow-up with Dr. \[Name] soon.\&#xA;**&#x20;**Let’s fill in your check-in form to help your doctor prepare.”**

**Form Prompts:**

* **“What’s your average BP over the last 5 days?”\&#xA;**
* **“Did you miss any medications?”\&#xA;**
* **“Rate your chest discomfort (1–10).”\&#xA;**
* **“Do you have any questions for your doctor?”\&#xA;**

**After completion:**

**“Thank you! I’ve sent your report to Dr. \[Name]. You’ll receive a reminder call on \[Date].”**

**📄** ***Generated PDF → Sent via FHIR API → Doctor dashboard.***



***



### **6. POST-CHECK VALIDATION & DAILY WRAP-UP**

**After completing all steps, AI Agent concludes:**

**“All tasks completed! Great job staying on track.\&#xA;**&#x20;**I’ll check in with you again at 9 PM for your evening session.”**

**If unfinished tasks remain:**

**“You still need to log your blood pressure. Would you like to complete it now?”**

**→ If Yes: restart from Step 1.\&#xA;**&#x20;**→ If No: schedule reminder for 2 hours later.**



***



### **7. EVENING ROUTINE (09:00 PM)**

**AI Agent:**

**“Good evening, \[Patient Name]. Let’s finish your daily check.”\&#xA;**&#x20;**(Same as morning routine → checks vitals, medications, symptoms.)**

**After completion:**

**“Thank you for staying consistent today!\&#xA;**&#x20;**I’ll send your daily summary to your care team and check in tomorrow at 9 AM.”**



***



### **8. WEEKLY & MONTHLY LOOPS**

**Weekly (Watsonx.ai event):**

**“How satisfied are you with your recovery progress this week?\&#xA;**&#x20;**Please rate from 1–10.”**

**→** ***Logs user sentiment in Recovery Dashboard.***

**30-Day Completion:**

**“Congratulations! You’ve completed your 30-day recovery plan.\&#xA;**&#x20;**I’ve shared your progress summary with your doctor.”**

**Long-Term Follow-up:**

**“I’ll continue checking in once a month to keep your recovery on track.”**



***



### **9. ESCALATION LOGIC SUMMARY**

**Condition**

**Trigger**

**System Action**

**Pain ≥ 9 or BP > threshold**

**Real-time**

**Critical alert to hospital + caregiver**

**Pain 6–8**

**Daily**

**Notify care team dashboard**

**No response for 2 consecutive checks**

**48 hours**

**Caregiver follow-up alert**

**Weekly satisfaction < 4**

**End of week**

**Notify support nurse to call patient**

### **10. SYSTEM ARCHITECTURE (INTEGRATION MAP)**

**Module**

**Role**

**Integration**

**Profile Loader**

**Retrieve User ID, Priority flag, and profile metadata**

**EHR/CRM API**

**Recovery Plan Manager**

**Store plan periods, medications, diet schedules**

**Excel/PDF data import**

**Notification Engine**

**Send push notifications & reminders**

**Watson Orchestrate**

**Conversational Core**

**Dialogue logic, escalation handling**

**watsonx.ai Assistant**

**Care Team Interface**

**Send alerts, summaries, and pre-call forms**

**FHIR API to Hospital EHR**



## **🧭 SUMMARY OF CONVERSATIONAL TONE & BEHAVIOR**

* **Short, clear, empathetic sentences.\&#xA;**
* **Always validate numeric inputs (BP format, pain scale, satisfaction rating).\&#xA;**
* **Offer clear next steps (“Would you like me to remind you again?”).\&#xA;**
* **Reassure and encourage after every completed task.\&#xA;**
* **Maintain continuity — each conversation builds on previous logs.**

**\&#xA;**
