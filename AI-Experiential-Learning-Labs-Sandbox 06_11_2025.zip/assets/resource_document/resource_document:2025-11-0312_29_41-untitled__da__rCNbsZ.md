```
{
  "model": "granite-3.3-8b-instruct",
  "name": "Watsonx Recovery Agent - Cardiac Recovery Flow",
  "nodes": [
    {
      "id": "onboarding",
      "type": "prompt",
      "text": "Welcome home, [Patient Name]. I\u2019m your Watson Recovery Assistant."
    },
    {
      "id": "profile_initialization",
      "type": "action",
      "actions": [
        "retrieve_user_profile",
        "check_priority_flag"
      ]
    },
    {
      "id": "caregiver_check",
      "type": "decision",
      "prompt": "Do you have a caregiver assisting you today?",
      "branches": {
        "yes": "standard_mode_activation",
        "no": "priority_mode_activation"
      }
    },
    {
      "id": "recovery_plan_activation",
      "type": "system",
      "action": "retrieve_recovery_plan"
    },
    {
      "id": "daily_cycle",
      "type": "loop",
      "trigger": [
        "09:00 AM",
        "09:00 PM"
      ],
      "steps": [
        {
          "prompt": "Please share your BP reading (e.g., 120/80)."
        },
        {
          "prompt": "Have you taken your [Morning/Evening] meds?"
        },
        {
          "prompt": "Rate your chest discomfort (1\u201310).",
          "branches": {
            "low": "lifestyle_reminder",
            "medium": "notify_care_team",
            "high": "risk_escalation"
          }
        }
      ]
    },
    {
      "id": "risk_escalation",
      "type": "condition",
      "logic": {
        "if_critical": "alert_care_team",
        "else": "lifestyle_reminder"
      }
    },
    {
      "id": "lifestyle_reminder",
      "type": "prompt",
      "text": "Maintain a low-sodium diet and drink 8 cups of water."
    },
    {
      "id": "closure",
      "type": "prompt",
      "text": "Thanks for completing today\u2019s check-in. I\u2019ll remind you tomorrow at 9 AM."
    }
  ]
}
```

